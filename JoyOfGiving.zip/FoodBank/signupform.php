 <link rel="stylesheet" type="text/css" href="vendors/css/normalize.css">
    <link rel="stylesheet" type="text/css" href="vendors/css/ionicons.min.css">
    <link rel="stylesheet" type="text/css" href="vendors/css/grid.css">
   <link rel="stylesheet" type="text/css" href="resources/css/style.css">
   <link rel="stylesheet" type="text/css" href="resources/css/queries.css">
<div style="background-color:#ededed; padding-bottom:100px;">
<div class="row" >
<form method="post"  class="contact-form" style="background-color: #d0cece; padding:20px;margin-top:40px; border-radius: 15px 50px 30px 5px; " >

    
    <h4 style=" margin-top:70px; margin-bottom:20px;">Please fill the following details</h3>
            <form method="post" action="#" class="contact-form">
                <div class="row">
                <div class="col span-1-of-3">
                <label>Enter Amount</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="Amount" id="name" placeholder="Amount you wish to contribute" required>
                </div>
                </div>
            <div class="row">
                <div class="col span-1-of-3">
                <label>Name</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="name" id="name" placeholder="Your Name" required>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>UPI id</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="upi" id="upi" placeholder="Your upi id" required>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>Drop us a line</label>
                
                </div>
                <div class="col span-2-of-3">
                <textarea name="message" placeholder="Your Message"></textarea>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>&nbsp;</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="submit" value="Proceed to Pay ">
                </div>
                </div>
            </form>
        </div>
    </div>
