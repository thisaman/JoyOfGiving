 <link rel="stylesheet" type="text/css" href="vendors/css/normalize.css">
    <link rel="stylesheet" type="text/css" href="vendors/css/ionicons.min.css">
    <link rel="stylesheet" type="text/css" href="vendors/css/grid.css">
   <link rel="stylesheet" type="text/css" href="resources/css/style.css">
   <link rel="stylesheet" type="text/css" href="resources/css/queries.css">
<div style="background-color:#ededed; padding-bottom:100px;">
<div class="row" >
<form method="post"  class="contact-form" style="background-color: #d0cece; padding:20px;margin-top:40px; border-radius: 15px 50px 30px 5px; " >

    
    <h2 style=" margin-top:70px; margin-bottom:20px;">Request food support</h2>
            <form method="post" action="#" class="contact-form">
                <div class="row">
                    
                <div class="col span-1-of-3">
                <label>Organisation Name:</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="name" id="name" placeholder="Enter organisation name" required>
                </div>
                </div>
            <div class="row">
                <div class="col span-1-of-3">
                <label>Address</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="address" id="address" placeholder="Enter address" required>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>PIN Code</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="text" name="pincode" id="pincode" placeholder="PIN Code" required>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>Contact no.</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="tel" name="contactno" id="contactno" placeholder="Contact No" required>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>Any important information:</label>
                
                </div>
                <div class="col span-2-of-3">
                <textarea name="" placeholder="Your Message"></textarea>
                </div>
                </div>
                
                <div class="row">
                <div class="col span-1-of-3">
                <label>&nbsp;</label>
                
                </div>
                <div class="col span-2-of-3">
                <input type="submit" value="Send Request">
                </div>
                </div>
            </form>
        </div>
    </div>
